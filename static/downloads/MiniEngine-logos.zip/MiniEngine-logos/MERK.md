# Mini Engine — merk v1.0 (oktober 2026)

Mini Engine is een kleine Rust-engine voor gezelschapsspellen met vrienden: één kamer, iedereen op zijn eigen telefoon, optioneel een gedeeld tv-scherm. De server is het middelpunt; alle apparaten zitten eromheen.

## Naam

- In lopende tekst: **Mini Engine** (twee woorden, hoofdletters).
- Als logo: **miniengine✳** — altijd uit de bestanden, nooit natypen.
- Producten: Mini Engine (de engine), Mini Engine SDK, Mini Engine Docs.

## Logo

- **Woordmerk**: `mini` in Space Grotesk SemiBold, `engine` in Space Grotesk Regular in een lichtere toon, gevolgd door het symbool. Letterspatiëring −0,04 em. Bronbestanden: `bron/master/woordmerk-*.svg` (letters zijn paden).
- **Symbool ✳**: acht afgeronde spaken die in het midden samenkomen — één middelpunt, acht stoelen eromheen. In het woordmerk dun (spaakdikte ≈ het Regular-gewicht); los gebruikt (favicon, app-icoon, avatar) dikker zodat het op 16 px overeind blijft.
- Op licht: `mini` Inkt, `engine` Steen, symbool Inkt.
- Op donker: `mini` Kalk, `engine` Nevel, symbool **Vonk**.
- `currentcolor`-varianten volgen de tekstkleur; `engine` staat dan op 62 % dekking.
- Vrije ruimte rondom: minimaal de hoogte van de x-hoogte. Minimale breedte woordmerk: 96 px.
- Niet doen: het symbool vervangen door een tekstteken, kleuren omdraaien (gele letters), het woordmerk in hoofdletters zetten, schaduwen of verlopen op het logo.

## Kleur

| Naam | Hex | Rol |
| --- | --- | --- |
| Kalk | `#EEF0EC` | paginagrond |
| Wit | `#FAFBF9` | vlakken, invoervelden |
| Inkt | `#1E2823` | tekst, primaire knop, donkere grond |
| Nacht | `#141B17` | diepste grond (tv-scherm, banners) |
| Steen | `#6F7A72` | secundaire tekst, "engine" |
| Nevel | `#9DA79F` | secundaire tekst op donker |
| Lijn | `#D5DAD4` | haarlijnen en randen |
| Vonk | `#F2C230` | accent |
| Goed | `#2F7A4F` | bevestiging |
| Fout | `#B23A2B` | fouten |

**Vonk is schaars.** Alleen voor het symbool op donker en voor signalen die iets *nu* betekenen: live, klaar, jij bent aan de beurt, focusring. Nooit als vlakvulling van grote delen, nooit als tekstkleur op licht.

## Type

- **Space Grotesk** (500/600): woordmerk, koppen, kamercodes, scores en andere cijfers.
- **DM Sans** (400/500/600): lopende tekst en interface.
- Code: systeem-monospace (`ui-monospace`, SF Mono, Menlo).
- Beide lettertypes zijn OFL en worden zelf gehost (geen Google Fonts-verzoeken; de engine-CSP staat alleen `'self'` toe).
- Zinnen, geen labels: sentence case, geen hoofdletterlabels boven koppen, geen rijen met middelpunten als opsomming.

## Principes

1. **Eén ding per scherm.** Elke pagina heeft één hoofdactie. De rest staat erachter of eronder.
2. **Rust in de schil, sfeer in het spel.** De Mini Engine-schil (kopbalk, kamercode, kamerbeheer) is stil en overal gelijk. Elk spel brengt zijn eigen wereld mee: vilt voor Common Dice, tv-studio voor Jeopardy.
3. **Groot waar het telt.** Kamercodes, scores, de buzzer en de worp zijn groot; uitleg is klein en kort.
4. **Telefoon eerst.** Spelersschermen zijn ontworpen voor één hand; het gedeelde scherm is leesbaar vanaf de bank.

## Tokens

`bron/tokens.css` bevat alle waarden als CSS custom properties (`--me-*`).
